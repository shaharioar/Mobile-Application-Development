package org.kashisol.mobilediagnostictool;


import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class IlluminationActivity extends AppCompatActivity {

    ListView listView ;
    SensorManager sensorManager ;
    List<Sensor> listsensor;
    List<String> liststring ;
    ArrayAdapter<String> adapter ;
    TextView t;
    int sum=0;
    String s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_illumination);

        listView = (ListView)findViewById(R.id.listview1);
        t=(TextView) findViewById(R.id.c);





        liststring = new ArrayList<String>();

        sensorManager = (SensorManager)getSystemService(Context.SENSOR_SERVICE);

        listsensor = sensorManager.getSensorList(Sensor.TYPE_ALL);

        for(int i=0; i<listsensor.size(); i++){

            liststring.add(listsensor.get(i).getName());
//            sum=sum+i;
            sum= liststring.size();

            if(sum>1){
                t.setText("Total "+sum+" Sensors Available on Your Device");
            }
            else{
                t.setText("Total "+sum+" Sensor Available on Your Device");
            }


        }

        adapter = new ArrayAdapter<String>(IlluminationActivity.this,
                android.R.layout.simple_list_item_2,
                android.R.id.text1, liststring
        );

        listView.setAdapter(adapter);

    }
}
package org.kashisol.mobilediagnostictool;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Configuration;
import android.graphics.Point;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.widget.TextView;
import android.widget.Toast;

public class ScreenCalibrationActivity extends AppCompatActivity {

    private static final String TAG = "";
    int height;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen_calibration);



        TextView txSize = (TextView) findViewById(R.id.tvSize);
        TextView widthPixels1 = (TextView) findViewById(R.id.H1);

        TextView density = (TextView) findViewById(R.id.density);
        TextView densityDpi = (TextView) findViewById(R.id.densityDpi);
        TextView widthPixels = (TextView) findViewById(R.id.widthPixels);
        TextView xdpi = (TextView) findViewById(R.id.xdpi);
        TextView ydpi = (TextView) findViewById(R.id.ydpi);
        TextView textScreenResolution=(TextView) findViewById(R.id.resulation);
        textScreenResolution.setText("Screen Resulation: "+getDeviceScreenResolution());


        Configuration config = getResources().getConfiguration();


        DisplayMetrics displayMetrics = new DisplayMetrics();

        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);



        if ((getResources().getConfiguration().screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) == Configuration.SCREENLAYOUT_SIZE_LARGE) {
            Toast.makeText(this, "Large screen", Toast.LENGTH_LONG).show();
            txSize.setText("Large screen");
        } else if ((getResources().getConfiguration().screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) == Configuration.SCREENLAYOUT_SIZE_NORMAL) {
            Toast.makeText(this, "Normal sized screen", Toast.LENGTH_LONG)
                    .show();
            txSize.setText("Normal sized screen");
        } else if ((getResources().getConfiguration().screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) == Configuration.SCREENLAYOUT_SIZE_SMALL) {
            Toast.makeText(this, "Small sized screen", Toast.LENGTH_LONG)
                    .show();
            txSize.setText("Small sized screen");
        } else if ((getResources().getConfiguration().screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) == Configuration.SCREENLAYOUT_SIZE_XLARGE) {
            Toast.makeText(this, "xLarge sized screen", Toast.LENGTH_LONG)
                    .show();
            txSize.setText("Small sized screen");
        } else {
            Toast.makeText(this,
                    "Screen size is neither large, normal or small",
                    Toast.LENGTH_LONG).show();
            txSize.setText("Screen size is neither large, normal or small");
        }

        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics metrics = new DisplayMetrics();


        display.getMetrics(metrics);

        Log.i(TAG, "density :" + metrics.density);
        density.setText("density :" + metrics.density);

        Log.i(TAG, "D density :" + metrics.densityDpi);
        densityDpi.setText("densityDpi :" + metrics.densityDpi);

        Log.i(TAG, "width pix :" + metrics.widthPixels);
        widthPixels.setText("Width Pixels :" + metrics.widthPixels);

        Log.i(TAG, "Height pix :" + metrics.heightPixels);
        widthPixels1.setText("Height Pixels :" + metrics.heightPixels);

        Log.i(TAG, "xdpi :" + metrics.xdpi);
        xdpi.setText("xdpi :" + metrics.xdpi);

        Log.i(TAG, "ydpi :" + metrics.ydpi);
        ydpi.setText("ydpi :" + metrics.ydpi);
    }

    public String getDeviceScreenResolution() {
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);

        int width = size.x; //device width
        int height = size.y; //device height

        return "" + width + " x " + height; //example "480 * 800"
    }
}